/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi3.JavaHell.fastFood.ResultServlets;

import br.senac.tads.pi3.JavaHell.fastFood.dao.FuncionarioDao;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author JavaHell
 */
@WebServlet(name = "LoginServlet02", urlPatterns = {"/LoginServlet02"})
public class LoginServlet02 extends HttpServlet {

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            HttpSession sessao = request.getSession(); 
            FuncionarioDao funcionarioDao = new FuncionarioDao();
            String senha = funcionarioDao.selecionaHashSenha(request.getParameter("username"));
            sessao.setAttribute("Cargo", funcionarioDao.getCargo());
            String senhaDigitada = this.geraHashSenha(request.getParameter("password"));
            Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            sessao.setAttribute("usuarioLogado", funcionarioDao.selecionaNomeByCpfSenha(request.getParameter("username") , senha));
            sessao.setAttribute("Id", funcionarioDao.selecionaIdByCpfSenha(request.getParameter("username"), senha));

            if (senha == null) {
                this.getServletContext().getRequestDispatcher("/WEB-INF/ErroLogin.jsp").forward(request, response);
            } else if (senha.equals(senhaDigitada)) {
                this.getServletContext().getRequestDispatcher("/WEB-INF/Home.jsp").forward(request, response);
            } else {
                this.getServletContext().getRequestDispatcher("/WEB-INF/ErroLogin.jsp").forward(request, response);
            }
        } catch (SQLException | NoSuchAlgorithmException | UnsupportedEncodingException e) {
            this.getServletContext().getRequestDispatcher("/WEB-INF/ErroLogin.jsp").forward(request, response);
            System.out.println(e);
        }

    }

    /**
     * Retorna uma hash de senha
     * 
     * @param senha
     * @return 
     * @throws java.security.NoSuchAlgorithmException
     * @throws java.io.UnsupportedEncodingException
    */
    public String geraHashSenha(String senha) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest algorithm = MessageDigest.getInstance("SHA-256");
        byte messageDigestSenha[] = algorithm.digest(senha.getBytes("UTF-8"));

        StringBuilder hexStringSenha = new StringBuilder();
        for (byte b : messageDigestSenha) {
            hexStringSenha.append(String.format("%02X", 0xFF & b));
        }
        return hexStringSenha.toString();
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
