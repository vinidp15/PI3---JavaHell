/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi3.JavaHell.fastFood.ResultServlets;

import br.senac.tads.pi3.JavaHell.fastFood.dao.ProdutosDao;
import br.senac.tads.pi3.JavaHell.fastFood.entidades.Produto;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author JavaHell
 */
@WebServlet(name = "RemoverProdutoServlet2", urlPatterns = {"/RemoverProdutoServlet2"})
public class RemoverProdutoServlet02 extends HttpServlet {

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ProdutosDao produtosDao = new ProdutosDao();
        HttpSession sessao = request.getSession(); 
        request.setAttribute("usuarioLogado", sessao.getAttribute("usuarioLogado"));
        Produto produto = null;
        try {
            try {
                
               //O nome do produto obtido pelo name será enviado como parâmetro no metodo que seleciona o produto,
               //o metodo retornara uma variavel do tipo produto, a qual sera atribuida a outra variavel do tipo produto.
               produto = new Produto((Produto) produtosDao.selecionaProduto(request.getParameter("nomeProduto")));
            } catch (NullPointerException | NumberFormatException e) {
                System.out.println(e);
                
                 //Caso caia no cath, os valores setados no Servlet serao enviados para a JSP passada no paramentro abaixo
                this.getServletContext().getRequestDispatcher("/WEB-INF/ErroGenerico.jsp").forward(request, response);
            }
            
            //Se a variavel produto for nula, e porque o produto obtido pelo name nao esta presente no sistema, caso contrario
            //seus atributo serao setados e enviados para a JSP
            if (produto != null) {
                
                //Setando os valores que serão resgatados pela JSP
                request.setAttribute("id", produto.getId_produto());
                request.setAttribute("categoria", produto.getCategoria());
                request.setAttribute("nome", produto.getNome());
                request.setAttribute("tamanho", produto.getTamanho());
                request.setAttribute("quantidade", produto.getQuantidade());
                
                //Metodo que ira remover o produto
                produtosDao.removeProduto(produto);
                
                //Setando o valor que ira ser resgatado na JSP
                request.setAttribute("produto", "Produto: " + produto.getNome() + " removido com sucesso!!");
                
                //Enviando os valores setados no servlet para a JSP determinado no parametro
                this.getServletContext().getRequestDispatcher("/WEB-INF/RemoveProd.jsp").forward(request, response);
            }
        } catch (NumberFormatException | SQLException e) {
            System.out.println(e);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
