/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi3.JavaHell.fastFood.ResultServlets;

import java.util.Date;
import br.senac.tads.pi3.JavaHell.fastFood.dao.MovimentacaoDao;
import br.senac.tads.pi3.JavaHell.fastFood.dao.ProdutosDao;
import br.senac.tads.pi3.JavaHell.fastFood.entidades.Movimentacao;
import br.senac.tads.pi3.JavaHell.fastFood.entidades.Venda;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * @author JavaHell
 */
@WebServlet(name = "VendProdServlet02", urlPatterns = {"/VendProdServlet02"})
public class VendProdServlet02 extends HttpServlet {

    private int[][] idQtd;
    static String errorMessage;

    public VendProdServlet02() {
        this.idQtd = new int[1][1];
    }

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }
    
    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sessao = request.getSession(); 
        request.setAttribute("usuarioLogado", sessao.getAttribute("usuarioLogado"));
        try {
            ProdutosDao produtosDao = new ProdutosDao();
            if (this.ValidateFields(request)) {
                this.idQtd = new int[this.preencheTamanhoMatriz(request)][2];
                this.populaMatriz(idQtd, request);
                this.resgistraQuantidade(idQtd, request);
                produtosDao.itensVenda();
                request.setAttribute("produtos", produtosDao.getProdutos());
                request.setAttribute("vendamsg","Venda efetuada com sucesso. "
                        + "Total da sua compra R$ " + this.totalCompra(request, produtosDao));
                this.getServletContext().getRequestDispatcher("/WEB-INF/VendProd.jsp").forward(request, response);
            } else {
                request.setAttribute("mensagem", VendProdServlet02.errorMessage);
                VendProdServlet02.errorMessage = null;
                this.getServletContext().getRequestDispatcher("/WEB-INF/ErroNaoAutorizado.jsp").forward(request, response);
            }
        } catch (NumberFormatException | SQLException e) {
            System.out.println(e);
        }
    }

    /**
    * Valida os campos de entrada da venda
    * 
    * @param request
    * @return
    */
    public boolean ValidateFields(HttpServletRequest request) {
        ProdutosDao obj = new ProdutosDao();
        boolean ret = true;

        try {
            if ((!request.getParameter("prod1").equals("Nenhum")) && Integer.parseInt(request.getParameter("qtd01")) <= 0) {
                VendProdServlet02.errorMessage = "A quantidade do item 1 deve ser preenchido.";
                ret = false;
            } else if ((!request.getParameter("prod2").equals("Nenhum")) && Integer.parseInt(request.getParameter("qtd02")) <= 0) {
                VendProdServlet02.errorMessage = "A quantidade do item 2 deve ser preenchido.";
                ret = false;
            } else if ((!request.getParameter("prod3").equals("Nenhum")) && Integer.parseInt(request.getParameter("qtd03")) <= 0) {
                VendProdServlet02.errorMessage = "A quantidade do item 3 deve ser preenchido.";
                ret = false;
            } else if (request.getParameter("prod1").equals("Nenhum") && Integer.parseInt(request.getParameter("qtd01")) > 0) {
                VendProdServlet02.errorMessage = "O item 1 deve ser preenchido.";
                ret = false;
            } else if (request.getParameter("prod2").equals("Nenhum") && Integer.parseInt(request.getParameter("qtd02")) > 0) {
                VendProdServlet02.errorMessage = "O item 2 deve ser preenchido.";
                ret = false;
            } else if (request.getParameter("prod3").equals("Nenhum") && Integer.parseInt(request.getParameter("qtd03")) > 0) {
                VendProdServlet02.errorMessage = "O item 3 deve ser preenchido.";
                ret = false;
            } else if ((request.getParameter("prod1").substring(4, 6).replace(",", "").replace(" ", "").equals(request.getParameter("prod2").substring(4, 6).replace(",", "").replace(" ", ""))
                    && !request.getParameter("prod1").equals("Nenhum"))
                    || (request.getParameter("prod1").substring(4, 6).replace(",", "").replace(" ", "").equals(request.getParameter("prod3").substring(4, 6).replace(",", "").replace(" ", ""))
                    && !request.getParameter("prod2").equals("Nenhum"))
                    || (request.getParameter("prod2").substring(4, 6).replace(",", "").replace(" ", "").equals(request.getParameter("prod3").substring(4, 6).replace(",", "").replace(" ", ""))
                    && !request.getParameter("prod3").equals("Nenhum"))) {
                VendProdServlet02.errorMessage = "Escolha um item e sua quantidade somente uma vez.";
                ret = false;
            } else if ((!request.getParameter("prod1").equals("Nenhum"))
                    || (!request.getParameter("prod2").equals("Nenhum"))
                    || (!request.getParameter("prod3").equals("Nenhum"))) {
                if (!request.getParameter("prod1").equals("Nenhum")) {
                    if (Integer.parseInt(request.getParameter("qtd01")) > obj.somaProdutoEmEstoque(Integer.parseInt(request.getParameter("prod1").substring(4, 6).replace(",", "").replace(" ", "")))) {
                        VendProdServlet02.errorMessage = "O Primeiro item tem não possui a quantidade disponível solicitada.";
                        ret = false;
                    }
                }
                if (!request.getParameter("prod2").equals("Nenhum")) {
                    if (Integer.parseInt(request.getParameter("qtd02")) > obj.somaProdutoEmEstoque(Integer.parseInt(request.getParameter("prod2").substring(4, 6).replace(",", "").replace(" ", "")))) {
                        VendProdServlet02.errorMessage = "O Segundo item tem não possui a quantidade disponível solicitada.";
                        ret = false;
                    }
                }
                if (!request.getParameter("prod3").equals("Nenhum")) {
                    if (Integer.parseInt(request.getParameter("qtd03")) > obj.somaProdutoEmEstoque(Integer.parseInt(request.getParameter("prod3").substring(4, 6).replace(",", "").replace(" ", "")))) {
                        VendProdServlet02.errorMessage = "O Terceiro item tem não possui a quantidade disponível solicitada.";
                        ret = false;
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return ret;
    }

    /**
    * Prenche o tamanho dinamico da matriz id e quantidade 
    *
    * @param request
    * @param response
    */
    public int preencheTamanhoMatriz(HttpServletRequest request) {
        int tamanho = 0;
        if (!request.getParameter("prod1").equals("Nenhum")) {
            tamanho++;
        }
        if (!request.getParameter("prod2").equals("Nenhum")) {
            tamanho++;
        }
        if (!request.getParameter("prod3").equals("Nenhum")) {
            tamanho++;
        }
        return tamanho;
    }

    /**
    * Popula a matriz de id e quantidade de produto 
    *
    * @param matriz
    * @param request
    */
    public void populaMatriz(int[][] matriz, HttpServletRequest request) {
        int cont = -1;
        if (!request.getParameter("prod1").equals("Nenhum")) {
            cont++;
            matriz[cont][0] = Integer.parseInt(request.getParameter("prod1").substring(4, 7).replace(",", "").replace(" ", ""));
            matriz[cont][1] = Integer.parseInt(request.getParameter("qtd01"));
        }
        if (!request.getParameter("prod2").equals("Nenhum")) {
            cont++;
            matriz[cont][0] = Integer.parseInt(request.getParameter("prod2").substring(4, 7).replace(",", "").replace(" ", ""));
            matriz[cont][1] = Integer.parseInt(request.getParameter("qtd02"));
        }
        if (!request.getParameter("prod3").equals("Nenhum")) {
            cont++;
            matriz[cont][0] = Integer.parseInt(request.getParameter("prod3").substring(4, 7).replace(",", "").replace(" ", ""));
            matriz[cont][1] = Integer.parseInt(request.getParameter("qtd03"));
        }
    }

    /**
    * Registra a movimentação de venda
    * 
    * @param matriz
    * @param request
    */
    public void resgistraQuantidade(int[][] matriz, HttpServletRequest request) {
        ProdutosDao produtosDao = new ProdutosDao();
        MovimentacaoDao movimentacaoDao = new MovimentacaoDao();
        Movimentacao movimentacao = null;
        Venda venda = null;
        Date date = new Date();
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        HttpSession sessao = request.getSession();
        try {
            for (int i = 0; i < matriz.length; i++) {
                produtosDao.updateQuantidade(matriz[i][0], matriz[i][1], produtosDao.somaProdutoEmEstoque(matriz[i][0]), "Venda");
                venda = new Venda(movimentacaoDao.getCodMovimentacaoDisp()
                                              , "Venda"
                                              , Integer.parseInt(sessao.getAttribute("Id").toString())
                                              , matriz[i][0]
                                              , matriz[i][1]
                                              , dateFormat.format(date));
                movimentacaoDao.insereMovimentacao(venda);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    
    /**
    * Calcula o total da compra 
    *
    * @param request
    * @throws javax.servlet.ServletException
    */
    public double totalCompra(HttpServletRequest request, ProdutosDao obj) throws SQLException{
        int qtd1 = Integer.parseInt(request.getParameter("qtd01"));
        int qtd2 = Integer.parseInt(request.getParameter("qtd02"));
        int qtd3 = Integer.parseInt(request.getParameter("qtd03"));
        String id1 = null;
        String id2 = null;
        String id3 = null;
        String valor1 = "0", valor2 = "0", valor3 = "0"; 
        double v1 = 0.0, v2 = 0.0, v3 = 0.0;
        
        
        if (!request.getParameter("prod1").equals("Nenhum")){
            id1 = request.getParameter("prod1").substring(4, 7).replace(",", "").replace(" ", "");
        }
        
        if (!request.getParameter("prod2").equals("Nenhum")){
            id2 = request.getParameter("prod2").substring(4, 7).replace(",", "").replace(" ", "");
        }
        
        if (!request.getParameter("prod3").equals("Nenhum")){
            id3 = request.getParameter("prod3").substring(4, 7).replace(",", "").replace(" ", "");
        }
        
        if (id1 != null){
            valor1 = obj.selecionaPrecoPorId(Integer.parseInt(id1));
        }
        
        if (id2 != null){
            valor2 = obj.selecionaPrecoPorId(Integer.parseInt(id2));
        }
        
        if (id3 != null){
            valor3 = obj.selecionaPrecoPorId(Integer.parseInt(id3));
        }
        
        if (valor1.length() > 5){
            valor1 = valor1.replace(".", "").replace(",", ".");
        }
        else{
            valor1 = valor1.replace(",", ".");
        }
        if (valor2.length() > 5){
            valor2 = valor2.replace(".", "").replace(",", ".");
        }
        else{
            valor2 = valor2.replace(",", ".");
        }
        if (valor3.length() > 5){
            valor3 = valor3.replace(".", "").replace(",", ".");
        }
        else{
            valor3 = valor3.replace(",", ".");
        }
        
        if (!valor1.equals("0")){
            v1 = qtd1 * Double.parseDouble(valor1); 
        }
        
        if (!valor2.equals("0")){
            v2 = qtd2 * Double.parseDouble(valor2); 
        }
        
        if (!valor3.equals("0")){
            v3 = qtd3 * Double.parseDouble(valor3); 
        }
        
        return  v1 + v2 + v3;        
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
