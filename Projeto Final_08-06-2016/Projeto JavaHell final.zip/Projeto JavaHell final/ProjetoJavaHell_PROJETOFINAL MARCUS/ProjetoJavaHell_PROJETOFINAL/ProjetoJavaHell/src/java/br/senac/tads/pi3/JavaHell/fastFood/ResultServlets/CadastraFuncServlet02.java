/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi3.JavaHell.fastFood.ResultServlets;

import br.senac.tads.pi3.JavaHell.fastFood.dao.FuncionarioDao;

import br.senac.tads.pi3.JavaHell.fastFood.entidades.AnalistaTecnico;
import br.senac.tads.pi3.JavaHell.fastFood.entidades.AuxiliarGeral;
import br.senac.tads.pi3.JavaHell.fastFood.entidades.Diretor;
import br.senac.tads.pi3.JavaHell.fastFood.entidades.Funcionario;
import br.senac.tads.pi3.JavaHell.fastFood.entidades.Gerente;
import br.senac.tads.pi3.JavaHell.fastFood.entidades.Vendedor;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author JavaHell
 */
@WebServlet(name = "CadastraFuncServlet02", urlPatterns = {"/CadastraFuncServlet02"})
public class CadastraFuncServlet02 extends HttpServlet {

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, UnsupportedEncodingException {
        HttpSession sessao = request.getSession(); 
        request.setAttribute("usuarioLogado", sessao.getAttribute("usuarioLogado"));

        try {
            FuncionarioDao funcionarioDao = new FuncionarioDao();

            if (request.getParameter("cargo").equals("Gerente")) {
                
                //Instancio a Classe de acordo com o cargo retornado pelo request.getParameter
                Gerente gerente = new Gerente(funcionarioDao.getIdFuncionario(),
                        
                        //Criando a classe com os parametros recebidos pelo getParameter
                        request.getParameter("nome"),
                        request.getParameter("cpf"),
                        Integer.parseInt(request.getParameter("idade")),
                        request.getParameter("cargo"),
                        this.geraHashSenha(request.getParameter("senha")),
                        request.getParameter("sexo"));

                //Verifica se o Funcionario já está cadastrado
                boolean verifica = funcionarioDao.verificaFuncionario(gerente);

                if (verifica) {
                    
                    //Setando o valor que sera resgatado pela JSP
                    request.setAttribute("funcionario", "Funcionario já Cadastrado no Sistema!!!");
                    
                    //Enviando os valores setados no Servlet para a JSP
                    this.getServletContext().getRequestDispatcher("/WEB-INF/CadastraFunc.jsp").forward(request, response);
                } else {
                    
                    //Metodo que ira cadastrar o gerente
                    funcionarioDao.cadastrarFuncionario(gerente);
                    
                    //Setando o valor que sera resgatado pela JSP
                    request.setAttribute("funcionario", "Gerente: " + request.getParameter("nome") + " cadastrado com sucesso!!");
                    
                    //Enviando os valores setados no Servlet para a JSP
                    this.getServletContext().getRequestDispatcher("/WEB-INF/CadastraFunc.jsp").forward(request, response);
                }

            } else if (request.getParameter("cargo").equals("Diretor")) {
                //Instancio a Classe de acordo com o cargo retornado pelo request.getParameter
                Diretor diretor = new Diretor(funcionarioDao.getIdFuncionario(),
                        
                        //Criando a classe com os parametros recebidos pelo getParameter
                        request.getParameter("nome"),
                        request.getParameter("cpf"),
                        Integer.parseInt(request.getParameter("idade")),
                        request.getParameter("cargo"),
                        this.geraHashSenha(request.getParameter("senha")),
                        request.getParameter("sexo"));

                //Verifica se o Funcionario já está cadastrado 
                boolean verifica = funcionarioDao.verificaFuncionario(diretor);

                if (verifica) {
                    
                    //Setando o valor que sera resgatado pela JSP
                    request.setAttribute("funcionario", "Funcionario já Cadastrado no Sistema!!!");
                    
                    //Enviando os valores setados no Servlet para a JSP
                    this.getServletContext().getRequestDispatcher("/WEB-INF/CadastraFunc.jsp").forward(request, response);
                } else {
                    
                    //Metodo que ira cadastrar o diretor
                    funcionarioDao.cadastrarFuncionario(diretor);
                    
                    //Setando o valor que sera resgatado pela JSP
                    request.setAttribute("funcionario", "Diretor: " + request.getParameter("nome") + " cadastrado com sucesso!!");
                    
                    //Enviando os valores setados no Servlet para a JSP
                    this.getServletContext().getRequestDispatcher("/WEB-INF/CadastraFunc.jsp").forward(request, response);
                }

            } else if (request.getParameter("cargo").equals("Vendedor")) {
                //Instancio a Classe de acordo com o cargo retornado pelo request.getParameter
                Vendedor vendedor = new Vendedor(funcionarioDao.getIdFuncionario(),
                        
                        //Criando a classe com os parametros recebidos pelo getParameter
                        request.getParameter("nome"),
                        request.getParameter("cpf"),
                        Integer.parseInt(request.getParameter("idade")),
                        request.getParameter("cargo"),
                        this.geraHashSenha(request.getParameter("senha")),
                        request.getParameter("sexo"));

                //Verifica se o Funcionario já está cadastrado
                boolean verifica = funcionarioDao.verificaFuncionario(vendedor);

                if (verifica) {
                    
                    //Setando o valor que sera resgatado pela JSP
                    request.setAttribute("funcionario", "Funcionario já Cadastrado no Sistema!!!");
                    
                    //Enviando os valores setados no Servlet para a JSP
                    this.getServletContext().getRequestDispatcher("/WEB-INF/CadastraFunc.jsp").forward(request, response);
                } else {
                    
                    //Metodo que ira cadastrar o vendedor
                    funcionarioDao.cadastrarFuncionario(vendedor);
                    
                    //Setando o valor que sera resgatado pela JSP
                    request.setAttribute("funcionario", "Vendedor: " + request.getParameter("nome") + " cadastrado com sucesso!!");
                    
                    //Enviando os valores setados no Servlet para a JSP
                    this.getServletContext().getRequestDispatcher("/WEB-INF/CadastraFunc.jsp").forward(request, response);
                }

            } else if (request.getParameter("cargo").equals("AnalistaTecnico")) {
                //Instancio a Classe de acordo com o cargo retornado pelo request.getParameter
                AnalistaTecnico analistaT = new AnalistaTecnico(funcionarioDao.getIdFuncionario(),
                        
                        //Criando a classe com os parametros recebidos pelo getParameter
                        request.getParameter("nome"),
                        request.getParameter("cpf"),
                        Integer.parseInt(request.getParameter("idade")),
                        request.getParameter("cargo"),
                        this.geraHashSenha(request.getParameter("senha")),
                        request.getParameter("sexo"));

                //Verifica se o Funcionario já está cadastrado
                boolean verifica = funcionarioDao.verificaFuncionario(analistaT);

                if (verifica) {
                    
                    //Setando o valor que sera resgatado pela JSP
                    request.setAttribute("funcionario", "Funcionario já Cadastrado no Sistema!!!");
                    
                    //Enviando os valores setados no Servlet para a JSP
                    this.getServletContext().getRequestDispatcher("/WEB-INF/CadastraFunc.jsp").forward(request, response);
                } else {
                    
                    //Metodo que ira cadastrar o Analista
                    funcionarioDao.cadastrarFuncionario(analistaT);
                    
                    //Setando o valor que sera resgatado pela JSP
                    request.setAttribute("funcionario", "Analista Tecnico: " + request.getParameter("nome") + " cadastrado com sucesso!!");
                    
                    //Enviando os valores setados no Servlet para a JSP
                    this.getServletContext().getRequestDispatcher("/WEB-INF/CadastraFunc.jsp").forward(request, response);
                }

            } else {
                //Instancio a Classe de acordo com o cargo retornado pelo request.getParameter
                AuxiliarGeral analistaG = new AuxiliarGeral(funcionarioDao.getIdFuncionario(),
                        
                        //Criando a classe com os parametros recebidos pelo getParameter
                        request.getParameter("nome"),
                        request.getParameter("cpf"),
                        Integer.parseInt(request.getParameter("idade")),
                        request.getParameter("cargo"),
                        this.geraHashSenha(request.getParameter("senha")),
                        request.getParameter("sexo"));

                //Verifica se o Funcionario já está cadastrado
                boolean verifica = funcionarioDao.verificaFuncionario(analistaG);

                if (verifica) {
                    
                    //Setando o valor que sera resgatado pela JSP
                    request.setAttribute("funcionario", "Funcionario já Cadastrado no Sistema!!!");
                    
                    //Enviando os valores setados no Servlet para a JSP
                    this.getServletContext().getRequestDispatcher("/WEB-INF/CadastraFunc.jsp").forward(request, response);
                } else {
                    
                    //Metodo que ira cadastrar o Auxiliar
                    funcionarioDao.cadastrarFuncionario(analistaG);
                    
                    //Setando o valor que sera resgatado pela JSP
                    request.setAttribute("funcionario", " Auxiliar Geral: " + request.getParameter("nome") + " cadastrado com sucesso!!");
                    
                    //Enviando os valores setados no Servlet para a JSP
                    this.getServletContext().getRequestDispatcher("/WEB-INF/CadastraFunc.jsp").forward(request, response);
                }
            }

        } catch (NumberFormatException e) {
            System.out.println("Erro: " + e);
        } catch (NoSuchAlgorithmException | SQLException ex) {
            Logger.getLogger(CadastraFuncServlet02.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Este metodo retorna um hash para a senha
     *
     * @param senha
     * @return 
     * @throws java.security.NoSuchAlgorithmException 
     * @throws java.io.UnsupportedEncodingException
    */
    public String geraHashSenha(String senha) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest algorithm = MessageDigest.getInstance("SHA-256");
        byte messageDigestSenha[] = algorithm.digest(senha.getBytes("UTF-8"));

        StringBuilder hexStringSenha = new StringBuilder();
        for (byte b : messageDigestSenha) {
            hexStringSenha.append(String.format("%02X", 0xFF & b));
        }
        return hexStringSenha.toString();
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
