/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi3.JavaHell.fastFood.ResultServlets;

import br.senac.tads.pi3.JavaHell.fastFood.dao.ProdutosDao;
import br.senac.tads.pi3.JavaHell.fastFood.entidades.Produto;
import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author JavaHell
 */
@WebServlet(name = "CadastraProdServlet02", urlPatterns = {"/CadastraProdServlet02"})
public class CadastraProdServlet02 extends HttpServlet {


    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       HttpSession sessao = request.getSession(); 
       
       //Setando o valor que sera resgato na JSP
       request.setAttribute("usuarioLogado", sessao.getAttribute("usuarioLogado"));

       try{            
            ProdutosDao produtosDao = new ProdutosDao();
            
            //Criando a classe com os parametros recebidos pelo getParameter e pelo resultado do metodo getCodOperacaoDisp()
            Produto produto = new Produto(produtosDao.getCodOperacaoDisp()
                                        , request.getParameter("categoria")
                                        , request.getParameter("nome")
                                        , request.getParameter("tamanho")
                                        , request.getParameter("valor")
                                        , Integer.parseInt(request.getParameter("quantidade")));
            
            //Metodo que ira cadastrar o produto
            produtosDao.cadastrarProduto(produto);
            
            //Setando o valor que sera resgato na JSP
            request.setAttribute("produto", "Produto: " + request.getParameter("nome") + " cadastrado com sucesso!!");            
            
            //Enviando os valores setados no Servlet para a JSP
            this.getServletContext().getRequestDispatcher("/WEB-INF/CadastraProd.jsp").forward(request, response);
        }
        catch(NumberFormatException | SQLException e){
            System.out.println("Erro: " + e);
        }      
    }
    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}