/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi3.JavaHell.fastFood.ResultServlets;

import br.senac.tads.pi3.JavaHell.fastFood.dao.ProdutosDao;
import br.senac.tads.pi3.JavaHell.fastFood.entidades.Produto;
import static com.sun.corba.se.spi.presentation.rmi.StubAdapter.request;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author JavaJell
 */
@WebServlet(name = "AlterarProdutoServlet02", urlPatterns = {"/AlterarProdutoServlet02"})
public class AlterarProdutoServlet02 extends HttpServlet {

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

    }

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    * @throws java.io.IOException
    */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);

        } catch (SQLException ex) {
            Logger.getLogger(AlterarProdutoServlet02.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    * @throws java.io.IOException
    */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, NullPointerException {
        Produto produto = null;
        ProdutosDao produtosDao = new ProdutosDao();
        HttpSession sessao = request.getSession(); 
        request.setAttribute("usuarioLogado", sessao.getAttribute("usuarioLogado"));

        try {
            String operacao = request.getParameter("alterarBotao");
            if (operacao.equals("Pesquisar")) {
                try {
                    produto = new Produto((Produto) produtosDao.selecionaProduto(request.getParameter("nomeProduto")));
                } catch (NullPointerException | NumberFormatException e) {
                    System.out.println(e);
                    this.getServletContext().getRequestDispatcher("/WEB-INF/ErroGenerico.jsp").forward(request, response);
                }
                request.setAttribute("id", produto.getId_produto());
                request.setAttribute("categoria", produto.getCategoria());
                request.setAttribute("nome", produto.getNome());
                request.setAttribute("tamanho", produto.getTamanho());
                request.setAttribute("preco", produto.getPreco());
                request.setAttribute("quantidade", produto.getQuantidade());
                this.getServletContext().getRequestDispatcher("/WEB-INF/AlteraProd.jsp").forward(request, response);
            } else {
                produto = new Produto(Integer.parseInt(request.getParameter("id")), request.getParameter("categoria"), request.getParameter("nome"), request.getParameter("tamanho"), request.getParameter("preco"), Integer.parseInt(request.getParameter("quantidade")));
                produtosDao.alteraProduto(produto);
                request.setAttribute("produto", "Produto: " + request.getParameter("nome") + " alterado com sucesso!!");
                this.getServletContext().getRequestDispatcher("/WEB-INF/AlteraProd.jsp").forward(request, response);
            }
        } catch (NumberFormatException | SQLException | ServletException | IOException e) {
            System.out.println(e);
            this.getServletContext().getRequestDispatcher("/WEB-INF/ErroGenerico.jsp").forward(request, response);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
