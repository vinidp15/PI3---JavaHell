/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi3.JavaHell.fastFood.servlet;

import br.senac.tads.pi3.JavaHell.fastFood.dao.ProdutosDao;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author JavaHell
 */
public class EntradaProdServlet01 extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try{
            ProdutosDao obj = new ProdutosDao();
            obj.itensVenda();   
            
            //Setando o valor que sera resgatado na JSP
            request.setAttribute("produtos", obj.getProdutos());   
            
            HttpSession sessao = request.getSession(); 
            
            request.setAttribute("usuarioLogado", sessao.getAttribute("usuarioLogado"));
            
            //Comando que ira chamar a JSP passada no parametro
            request.getRequestDispatcher("WEB-INF/EntradaProd.jsp").forward(request, response);
        }
        catch(NumberFormatException | SQLException e){
            System.out.println(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
