/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi3.JavaHell.fastFood.ResultServlets;

import java.util.Date;
import br.senac.tads.pi3.JavaHell.fastFood.dao.MovimentacaoDao;
import br.senac.tads.pi3.JavaHell.fastFood.dao.ProdutosDao;
import br.senac.tads.pi3.JavaHell.fastFood.entidades.Entrada;
import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author JavaHell
 */
@WebServlet(name = "EntradaProdServlet02", urlPatterns = {"/EntradaProdServlet02"})
public class EntradaProdServlet02 extends HttpServlet {

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sessao = request.getSession(); 
        request.setAttribute("usuarioLogado", sessao.getAttribute("usuarioLogado"));
        try {
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            Date date = new Date();
            ProdutosDao produtosDao = new ProdutosDao();
            MovimentacaoDao movimentacaoDao = new MovimentacaoDao();
            Entrada entrada = null;
            
            //Atualiza a quantidade em estoque
            produtosDao.updateQuantidade(Integer.parseInt(request.getParameter("prod1").substring(4, 7).replace(",", "").replace(" ", ""))
                                       , Integer.parseInt(request.getParameter("qtd01"))
                                       , produtosDao.somaProdutoEmEstoque(Integer.parseInt(request.getParameter("prod1").substring(4, 7).replace(",", "").replace(" ", "")))
                                       , "Entrada");
            //Gera uma movimentacao de entrada
            entrada = new Entrada(movimentacaoDao.getCodMovimentacaoDisp()
                                , "Entrada"
                                , Integer.parseInt(sessao.getAttribute("Id").toString())
                                , Integer.parseInt(request.getParameter("prod1").substring(4, 7).replace(",", "").replace(" ", ""))
                                , Integer.parseInt(request.getParameter("qtd01"))
                                , dateFormat.format(date));
            movimentacaoDao.insereMovimentacao(entrada);
            produtosDao.itensVenda();
            request.setAttribute("produtos", produtosDao.getProdutos());
            request.setAttribute("entradamsg","Entrada de produto com sucesso!!");
            this.getServletContext().getRequestDispatcher("/WEB-INF/EntradaProd.jsp").forward(request, response);
            
        } catch (NumberFormatException | SQLException e) {
            System.out.println(e);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
