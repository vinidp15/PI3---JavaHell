/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi3.JavaHell.fastFood.relatorios;

import br.senac.tads.pi3.JavaHell.fastFood.entidades.Funcionario;
import java.util.List;

/**
 *
 * @author JavaHell
 */
public class RelatorioFuncionario {
    
    private List<Funcionario> relatorioFuncionarios;

       //Construtor da Classe
    public RelatorioFuncionario(List<Funcionario> relatorioFuncionarios) {
        this.relatorioFuncionarios = relatorioFuncionarios;
    }

    //Metodo que ira retornar o valor da variavel
    public List<Funcionario> getRelatorioFuncionarios() {
        return relatorioFuncionarios;
    }
    
}
