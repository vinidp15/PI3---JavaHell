/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi3.JavaHell.fastFood.relatorios;

import br.senac.tads.pi3.JavaHell.fastFood.entidades.Produto;
import java.util.List;

/**
 *
 * @author JavaHell
 */
public class RelatorioProduto {
    
    private List<Produto> relatoriosProdutos;

    //Construtor da Classe
    public RelatorioProduto(List<Produto> relatoriosProdutos) {
        this.relatoriosProdutos = relatoriosProdutos;
    }

    //Metodo que ira retornar o valor da variavel
    public List<Produto> getRelatoriosProdutos() {
        return relatoriosProdutos;
    }
    
}
