/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.senac.tads.pi3.JavaHell.fastFood.ResultServlets;

import br.senac.tads.pi3.JavaHell.fastFood.dao.FuncionarioDao;
import br.senac.tads.pi3.JavaHell.fastFood.dao.MovimentacaoDao;
import br.senac.tads.pi3.JavaHell.fastFood.dao.ProdutosDao;
import br.senac.tads.pi3.JavaHell.fastFood.relatorios.RelatorioFuncionario;
import br.senac.tads.pi3.JavaHell.fastFood.relatorios.RelatorioMovimentacoes;
import br.senac.tads.pi3.JavaHell.fastFood.relatorios.RelatorioProduto;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author JavaHell
 */
@WebServlet(name = "GeraRelatorioServlet02", urlPatterns = {"/GeraRelatorioServlet02"})
public class GeraRelatorioServlet02 extends HttpServlet {

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
    }

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(GeraRelatorioServlet02.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
    *
    * @param request
    * @param response
    * @throws javax.servlet.ServletException
    */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession sessao = request.getSession(); 
        request.setAttribute("usuarioLogado", sessao.getAttribute("usuarioLogado"));
        try {
            
            //Pegando o valor do name e atribuindo a variavel
            String tipoRelatorio = request.getParameter("tipoRelatorio");
            
            //O valor da variável decidirá em qual caso irá cair
            switch (tipoRelatorio) {
                case "listarProdutos": {
                    ProdutosDao produtosDao = new ProdutosDao();
                    
                    //A lista que ira retornar do metodo sera usado na criacao de uma nova classe
                    RelatorioProduto relatorioProduto = new RelatorioProduto(produtosDao.listaProdutos());
                    
                    //Setando os valores que serao resgatados pela JSP
                    request.setAttribute("relatorio", "Relatorio de produtos cadastrados!!");
                    request.setAttribute("relatorioprodutos", relatorioProduto.getRelatoriosProdutos());                    
                    
                    //Enviando os valores para a JSP
                    this.getServletContext().getRequestDispatcher("/WEB-INF/GeraRelatorio.jsp").forward(request, response);
                    break;
                }
                case "listarFuncionarios": {
                    FuncionarioDao funcionarioDao = new FuncionarioDao();
                    
                    //A lista que ira retornar do metodo sera usado na criacao de uma nova classe
                    RelatorioFuncionario relatorioFuncionario = new RelatorioFuncionario(funcionarioDao.listaFuncionarios());
                    
                    //Setando os valores que serao resgatados pela JSP
                    request.setAttribute("relatorio", "Relatorio de funcionarios cadastrados!!");
                    request.setAttribute("relatoriofuncionarios", relatorioFuncionario.getRelatorioFuncionarios());                    
                    
                    //Enviando os valores para a JSP
                    this.getServletContext().getRequestDispatcher("/WEB-INF/GeraRelatorio.jsp").forward(request, response);
                    break;
                }
                default: {
                    MovimentacaoDao movimentacaoDao = new MovimentacaoDao();
                    
                    //A lista que ira retornar do metodo sera usado na criacao de uma nova classe
                    RelatorioMovimentacoes RelatorioMovimentacoes = new RelatorioMovimentacoes(movimentacaoDao.listaMovimentacoes()); 
                    
                    //Setando os valores que serao resgatados pela JSP
                    request.setAttribute("relatorio", "Relatorio de movimentacoes de produtos!!");
                    request.setAttribute("relatoriomovimentacao", RelatorioMovimentacoes.getRelatorioMovimentacao());
                    
                    //Enviando os valores para a JSP
                    this.getServletContext().getRequestDispatcher("/WEB-INF/GeraRelatorio.jsp").forward(request, response);
                    break;
                }
            }
        } catch (IOException | SQLException | ServletException e) {
            System.out.println(e);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
